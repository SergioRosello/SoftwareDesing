package strategies;

public class Aggressive extends Strategy {

	public Aggressive() {
		attackRange = 7;
		defenseRange = 3;
	}
}
