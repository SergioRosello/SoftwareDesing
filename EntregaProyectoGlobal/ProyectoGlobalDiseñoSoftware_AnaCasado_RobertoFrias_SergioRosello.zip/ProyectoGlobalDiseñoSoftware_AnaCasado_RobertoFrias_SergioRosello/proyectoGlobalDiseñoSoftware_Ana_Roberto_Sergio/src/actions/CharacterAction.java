package actions;

public abstract class CharacterAction {
	
	public String action;
	public String decorator;
	
	public abstract int quantity();
}
