package states;

public interface CharacterState {
	void handle();
}